>screamPay'官方技术交流群：794220467 （加群暗号：screampay）。现已经升级到2.0，切换到分支screamPay2.0即可。简化了原来代理，商户信息，由原来的的rsa加密方式简化为md5，redis序列化改为fastjson方式。换了一套皮肤。

***

### 项目介绍
***

- `screamPay聚合支付,一个强大到让你尖叫的聚合支付系统` screamPay聚合支付使用Java开发，采用spring-boot、spring-cloud架构，已接入环讯、九派、杉德等主流支付渠道，可直接用于生产环境。

> [screamPay官网：]开发中

> [screamPay开发社区：]开发中

> [screamPay demo系统：] https://github.com/star-ruijie/screamPayDemo

> [screamPay支付体验：]  http://screampaydemo.1goldedu.cn/ScreamPayDemo/jsp/pay.jsp

> [screamPay运营平台演示：]  http://screampay.1goldedu.cn  (只开放商户登录) 用户名／密码   JFSH4409/123456  可以查看测试的订单

> [screamPay商户对接API文档：] https://github.com/star-ruijie/screamPay/blob/master/screamPay_API.docx 

> [screamPay使用手册：]  https://github.com/star-ruijie/screamPay/blob/master/user_guide.docx

### 版本更新
***

版本 |日期 |描述
------- | ------- | -------
V1.0.0 |2018-12-08 |首次发布

接下来的开源版本开发计划：
```html
+ 重点发展spring cloud架构版本；
+ 风控逻辑优化；
+ 持续增加其他支付渠道对接；
```

### 项目测试
------------



【运营平台截图】

![支付通道管理](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.32.02.png "screamPay运营平台")

![下发通道管理](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.32.38.png "screamPay运营平台")

![代理商管理](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.33.14.png  "screamPay运营平台")

![添加代理商](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.33.46.png "screamPay运营平台")

![商户管理](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.34.29.png  "screamPay运营平台")

![新增商户管理](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.34.52.png  "screamPay运营平台")

![支付交易查询](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.35.13.png  "screamPay运营平台")

![代付交易查询](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.35.26.png  "screamPay运营平台")

![提现交易查询](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.35.41.png  "screamPay运营平台")

![商户钱包管理](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.35.58.png  "screamPay运营平台")

![代理商钱包管理](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.36.12.png  "screamPay运营平台")

![平台钱包管理](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.36.20.png  "screamPay运营平台")

![第三方账户钱包管理](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.36.38.png  "screamPay运营平台")

![提现管理](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.36.52.png "screamPay运营平台")

![提现列表](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.37.03.png  "screamPay运营平台")

![支付订单同步管理](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.37.17.png "screamPay运营平台")

![代付订单同步管理](http://gongdingxi.cn/wp-content/uploads/2018/12/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7-2018-12-08-%E4%B8%8B%E5%8D%883.37.38.png "screamPay运营平台")


### 项目结构
***


### 项目部署
***
1.pay_juhe.sql为数据库，直接导入mysql即可。

2.application.yml为主配置文件。
```html
        port为工作端口，active为使用的具体配置文件，可选dev(意为使用application-dev.yml)和pro(意为使用application-pro.yml)。
```
3.application-dev.yml为开发配置。
```html
#log等级
logging:
  level:
    root: error
spring:
#数据库设置
  read-dataSource:
    driverClassName: com.mysql.jdbc.Driver
    url: jdbc:mysql://localhost:3306/pay_crypto?useUnicode=true&characterEncoding=utf8&useSSL=false&allowMultiQueries=true
    username: pay_crypto
    password: pay_crypto
  dataSource:
    type: com.alibaba.druid.pool.DruidDataSource
    driverClassName: com.mysql.jdbc.Driver
    url: jdbc:mysql://localhost:3306/pay_crypto?useUnicode=true&characterEncoding=utf8&useSSL=false&allowMultiQueries=true
    username: pay_crypto
    password: pay_crypto
    initialSize: 1
    minIdle: 3
    maxActive: 20
    # 配置获取连接等待超时的时间
    maxWait: 60000
    # 配置间隔多久才进行一次检测，检测需要关闭的空闲连接，单位是毫秒
    timeBetweenEvictionRunsMillis: 60000
    # 配置一个连接在池中最小生存的时间，单位是毫秒
    minEvictableIdleTimeMillis: 30000
    validationQuery: select 'x'
    testWhileIdle: true
    testOnBorrow: false
    testOnReturn: false
    # 打开PSCache，并且指定每个连接上PSCache的大小
    poolPreparedStatements: true
    maxPoolPreparedStatementPerConnectionSize: 20
    # 配置监控统计拦截的filters，去掉后监控界面sql无法统计，'wall'用于防火墙
    filters: stat,slf4j
    # 通过connectProperties属性来打开mergeSql功能；慢SQL记录
    connectionProperties: druid.stat.mergeSql=true;druid.stat.slowSqlMillis=5000
    # 合并多个DruidDataSource的监控数据
    #useGlobalDataSourceStat: true
  jpa:
    hibernate:
      #ddl-auto: create #ddl-auto:设为create表示每次都重新建表
      ddl-auto: update #ddl-auto:设为update表示每次都不会重新建表
    show-sql: true
  # REDIS (RedisProperties)
  redis: 
    # Redis服务器地址
    host: 127.0.0.1
    # Redis服务器连接端口
    port: 6379  
    # Redis服务器连接密码（默认为空）
    password: redis  
    # 连接池最大连接数（使用负值表示没有限制）
    pool: 
      max-active: 8  
        # 连接池最大阻塞等待时间（使用负值表示没有限制）
      max-wait: -1  
      # 连接池中的最大空闲连接
      max-idle: 8  
      # 连接池中的最小空闲连接
      min-idle: 0  
      # 连接超时时间（毫秒）
    timeout: 0
    #sentinel: 
      #master: mymaster  
    # comma-separated list of host:port pairs  哨兵的配置列表  
      #nodes: 192.168.1.188:26379,192.168.1.188:26479,192.168.1.188:26579
  task: 
    pool: 
      corePoolSize: 10  
      maxPoolSize: 20  
      keepAliveSeconds: 60  
      queueCapacity: 100  
      threadNamePrefix: myThreadPool 
redisson:
  password: redis
  # 单机模式
  address: redis://127.0.0.1:6379
  # 哨兵模式
  #master-name: mymaster
  #sentinel-addresses: redis://192.168.1.188:26379,redis://192.168.1.188:26479,redis://192.168.1.188:26579
```
4.后台默认登录账户／密码为：admin/123456

5.application-dev.yml和application-pro.yml配置文件里是设置了redis密码的，注意要和自己的redis保持一致。
	
6.logback.xml指定了日志输出目录，有问题可以查看日志。

7.这是一个Maven项目，请以Maven项目导到IDE。


作者已成功将项目部署在阿里云主机上，服务器配置为：

| CPU  | 内存 | 操作系统
|---|---|---
|1核 | 2 GB | CentOS 6.8 64位

安装的各软件对应的版本为（仅供参考）：

| 软件  | 版本 | 说明
|---|---|---
|JDK | 1.8 | spring boot 对低版支持没有测过
|Redis| 4.0.10 | 
|MySQL | 5.7.17 |

### 关于作者
***
姓名：龚丁禧

[龚丁禧个人主页](http://gongdingxi.cn "龚丁禧个人主页")
