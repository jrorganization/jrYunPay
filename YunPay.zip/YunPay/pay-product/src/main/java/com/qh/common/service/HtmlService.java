package com.qh.common.service;

public interface HtmlService {

    public String makeHtml(String orderNo, String content);

    public String make(String orderNo, String content);

}
